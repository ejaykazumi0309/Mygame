gdjs.DialogueCode = {};
gdjs.DialogueCode.GDDialogueObjects1= [];
gdjs.DialogueCode.GDDialogueObjects2= [];
gdjs.DialogueCode.GDFloatingOutButtonDarkBlueObjects1= [];
gdjs.DialogueCode.GDFloatingOutButtonDarkBlueObjects2= [];
gdjs.DialogueCode.GDWhiteBoardObjects1= [];
gdjs.DialogueCode.GDWhiteBoardObjects2= [];


gdjs.DialogueCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("FloatingOutButtonDarkBlue"), gdjs.DialogueCode.GDFloatingOutButtonDarkBlueObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.DialogueCode.GDFloatingOutButtonDarkBlueObjects1.length;i<l;++i) {
    if ( gdjs.DialogueCode.GDFloatingOutButtonDarkBlueObjects1[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.DialogueCode.GDFloatingOutButtonDarkBlueObjects1[k] = gdjs.DialogueCode.GDFloatingOutButtonDarkBlueObjects1[i];
        ++k;
    }
}
gdjs.DialogueCode.GDFloatingOutButtonDarkBlueObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "StartMenu", false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusic(runtimeScene, "ES_Horror Ghostly 1 - SFX Producer (1).mp3", true, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.DialogueCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.DialogueCode.GDDialogueObjects1.length = 0;
gdjs.DialogueCode.GDDialogueObjects2.length = 0;
gdjs.DialogueCode.GDFloatingOutButtonDarkBlueObjects1.length = 0;
gdjs.DialogueCode.GDFloatingOutButtonDarkBlueObjects2.length = 0;
gdjs.DialogueCode.GDWhiteBoardObjects1.length = 0;
gdjs.DialogueCode.GDWhiteBoardObjects2.length = 0;

gdjs.DialogueCode.eventsList0(runtimeScene);

return;

}

gdjs['DialogueCode'] = gdjs.DialogueCode;
