gdjs.Multiplayer_32LobbyCode = {};
gdjs.Multiplayer_32LobbyCode.GDBlueButtonWithShadowObjects1= [];
gdjs.Multiplayer_32LobbyCode.GDBlueButtonWithShadowObjects2= [];
gdjs.Multiplayer_32LobbyCode.GDBlueButtonWithShadow2Objects1= [];
gdjs.Multiplayer_32LobbyCode.GDBlueButtonWithShadow2Objects2= [];
gdjs.Multiplayer_32LobbyCode.GDFloatingOutButtonDarkBlueObjects1= [];
gdjs.Multiplayer_32LobbyCode.GDFloatingOutButtonDarkBlueObjects2= [];


gdjs.Multiplayer_32LobbyCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("FloatingOutButtonDarkBlue"), gdjs.Multiplayer_32LobbyCode.GDFloatingOutButtonDarkBlueObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Multiplayer_32LobbyCode.GDFloatingOutButtonDarkBlueObjects1.length;i<l;++i) {
    if ( gdjs.Multiplayer_32LobbyCode.GDFloatingOutButtonDarkBlueObjects1[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Multiplayer_32LobbyCode.GDFloatingOutButtonDarkBlueObjects1[k] = gdjs.Multiplayer_32LobbyCode.GDFloatingOutButtonDarkBlueObjects1[i];
        ++k;
    }
}
gdjs.Multiplayer_32LobbyCode.GDFloatingOutButtonDarkBlueObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Menu", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BlueButtonWithShadow"), gdjs.Multiplayer_32LobbyCode.GDBlueButtonWithShadowObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Multiplayer_32LobbyCode.GDBlueButtonWithShadowObjects1.length;i<l;++i) {
    if ( gdjs.Multiplayer_32LobbyCode.GDBlueButtonWithShadowObjects1[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Multiplayer_32LobbyCode.GDBlueButtonWithShadowObjects1[k] = gdjs.Multiplayer_32LobbyCode.GDBlueButtonWithShadowObjects1[i];
        ++k;
    }
}
gdjs.Multiplayer_32LobbyCode.GDBlueButtonWithShadowObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Create", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BlueButtonWithShadow2"), gdjs.Multiplayer_32LobbyCode.GDBlueButtonWithShadow2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Multiplayer_32LobbyCode.GDBlueButtonWithShadow2Objects1.length;i<l;++i) {
    if ( gdjs.Multiplayer_32LobbyCode.GDBlueButtonWithShadow2Objects1[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Multiplayer_32LobbyCode.GDBlueButtonWithShadow2Objects1[k] = gdjs.Multiplayer_32LobbyCode.GDBlueButtonWithShadow2Objects1[i];
        ++k;
    }
}
gdjs.Multiplayer_32LobbyCode.GDBlueButtonWithShadow2Objects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Join", false);
}}

}


};

gdjs.Multiplayer_32LobbyCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Multiplayer_32LobbyCode.GDBlueButtonWithShadowObjects1.length = 0;
gdjs.Multiplayer_32LobbyCode.GDBlueButtonWithShadowObjects2.length = 0;
gdjs.Multiplayer_32LobbyCode.GDBlueButtonWithShadow2Objects1.length = 0;
gdjs.Multiplayer_32LobbyCode.GDBlueButtonWithShadow2Objects2.length = 0;
gdjs.Multiplayer_32LobbyCode.GDFloatingOutButtonDarkBlueObjects1.length = 0;
gdjs.Multiplayer_32LobbyCode.GDFloatingOutButtonDarkBlueObjects2.length = 0;

gdjs.Multiplayer_32LobbyCode.eventsList0(runtimeScene);

return;

}

gdjs['Multiplayer_32LobbyCode'] = gdjs.Multiplayer_32LobbyCode;
