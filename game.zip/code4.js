gdjs.CreditsCode = {};
gdjs.CreditsCode.GDOWNERObjects1= [];
gdjs.CreditsCode.GDOWNERObjects2= [];
gdjs.CreditsCode.GDOWNER2Objects1= [];
gdjs.CreditsCode.GDOWNER2Objects2= [];
gdjs.CreditsCode.GDFloatingOutButtonDarkBlueObjects1= [];
gdjs.CreditsCode.GDFloatingOutButtonDarkBlueObjects2= [];


gdjs.CreditsCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("FloatingOutButtonDarkBlue"), gdjs.CreditsCode.GDFloatingOutButtonDarkBlueObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.CreditsCode.GDFloatingOutButtonDarkBlueObjects1.length;i<l;++i) {
    if ( gdjs.CreditsCode.GDFloatingOutButtonDarkBlueObjects1[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.CreditsCode.GDFloatingOutButtonDarkBlueObjects1[k] = gdjs.CreditsCode.GDFloatingOutButtonDarkBlueObjects1[i];
        ++k;
    }
}
gdjs.CreditsCode.GDFloatingOutButtonDarkBlueObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Menu", false);
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.CreditsCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.CreditsCode.GDOWNERObjects1.length = 0;
gdjs.CreditsCode.GDOWNERObjects2.length = 0;
gdjs.CreditsCode.GDOWNER2Objects1.length = 0;
gdjs.CreditsCode.GDOWNER2Objects2.length = 0;
gdjs.CreditsCode.GDFloatingOutButtonDarkBlueObjects1.length = 0;
gdjs.CreditsCode.GDFloatingOutButtonDarkBlueObjects2.length = 0;

gdjs.CreditsCode.eventsList0(runtimeScene);

return;

}

gdjs['CreditsCode'] = gdjs.CreditsCode;
