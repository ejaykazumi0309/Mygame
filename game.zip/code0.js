gdjs.MenuCode = {};
gdjs.MenuCode.GDFloatingOutButtonDarkBlueObjects1= [];
gdjs.MenuCode.GDFloatingOutButtonDarkBlueObjects2= [];
gdjs.MenuCode.GDFloatingOutButtonDarkBlue3Objects1= [];
gdjs.MenuCode.GDFloatingOutButtonDarkBlue3Objects2= [];
gdjs.MenuCode.GDFloatingOutButtonDarkBlue2Objects1= [];
gdjs.MenuCode.GDFloatingOutButtonDarkBlue2Objects2= [];
gdjs.MenuCode.GDTITLEObjects1= [];
gdjs.MenuCode.GDTITLEObjects2= [];
gdjs.MenuCode.GDFloatingOutButtonDarkBlue4Objects1= [];
gdjs.MenuCode.GDFloatingOutButtonDarkBlue4Objects2= [];
gdjs.MenuCode.GDFloatingOutButtonDarkBlue5Objects1= [];
gdjs.MenuCode.GDFloatingOutButtonDarkBlue5Objects2= [];
gdjs.MenuCode.GDGhostObjects1= [];
gdjs.MenuCode.GDGhostObjects2= [];
gdjs.MenuCode.GDLButtonObjects1= [];
gdjs.MenuCode.GDLButtonObjects2= [];
gdjs.MenuCode.GDBurgerMenuButtonObjects1= [];
gdjs.MenuCode.GDBurgerMenuButtonObjects2= [];


gdjs.MenuCode.mapOfGDgdjs_9546MenuCode_9546GDBurgerMenuButtonObjects1Objects = Hashtable.newFrom({"BurgerMenuButton": gdjs.MenuCode.GDBurgerMenuButtonObjects1});
gdjs.MenuCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("FloatingOutButtonDarkBlue"), gdjs.MenuCode.GDFloatingOutButtonDarkBlueObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MenuCode.GDFloatingOutButtonDarkBlueObjects1.length;i<l;++i) {
    if ( gdjs.MenuCode.GDFloatingOutButtonDarkBlueObjects1[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.MenuCode.GDFloatingOutButtonDarkBlueObjects1[k] = gdjs.MenuCode.GDFloatingOutButtonDarkBlueObjects1[i];
        ++k;
    }
}
gdjs.MenuCode.GDFloatingOutButtonDarkBlueObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Dialogue");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("FloatingOutButtonDarkBlue2"), gdjs.MenuCode.GDFloatingOutButtonDarkBlue2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MenuCode.GDFloatingOutButtonDarkBlue2Objects1.length;i<l;++i) {
    if ( gdjs.MenuCode.GDFloatingOutButtonDarkBlue2Objects1[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.MenuCode.GDFloatingOutButtonDarkBlue2Objects1[k] = gdjs.MenuCode.GDFloatingOutButtonDarkBlue2Objects1[i];
        ++k;
    }
}
gdjs.MenuCode.GDFloatingOutButtonDarkBlue2Objects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Credits", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("FloatingOutButtonDarkBlue3"), gdjs.MenuCode.GDFloatingOutButtonDarkBlue3Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MenuCode.GDFloatingOutButtonDarkBlue3Objects1.length;i<l;++i) {
    if ( gdjs.MenuCode.GDFloatingOutButtonDarkBlue3Objects1[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.MenuCode.GDFloatingOutButtonDarkBlue3Objects1[k] = gdjs.MenuCode.GDFloatingOutButtonDarkBlue3Objects1[i];
        ++k;
    }
}
gdjs.MenuCode.GDFloatingOutButtonDarkBlue3Objects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Multiplayer Lobby", false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusic(runtimeScene, "ES_Horror Metallic 1 - SFX Producer.mp3", true, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("FloatingOutButtonDarkBlue4"), gdjs.MenuCode.GDFloatingOutButtonDarkBlue4Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MenuCode.GDFloatingOutButtonDarkBlue4Objects1.length;i<l;++i) {
    if ( gdjs.MenuCode.GDFloatingOutButtonDarkBlue4Objects1[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.MenuCode.GDFloatingOutButtonDarkBlue4Objects1[k] = gdjs.MenuCode.GDFloatingOutButtonDarkBlue4Objects1[i];
        ++k;
    }
}
gdjs.MenuCode.GDFloatingOutButtonDarkBlue4Objects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.stopGame(runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("FloatingOutButtonDarkBlue5"), gdjs.MenuCode.GDFloatingOutButtonDarkBlue5Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MenuCode.GDFloatingOutButtonDarkBlue5Objects1.length;i<l;++i) {
    if ( gdjs.MenuCode.GDFloatingOutButtonDarkBlue5Objects1[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.MenuCode.GDFloatingOutButtonDarkBlue5Objects1[k] = gdjs.MenuCode.GDFloatingOutButtonDarkBlue5Objects1[i];
        ++k;
    }
}
gdjs.MenuCode.GDFloatingOutButtonDarkBlue5Objects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "About", false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.adMob.setupBanner("ca-app-pub-9295891708763537/7357192757", "", true);
}{gdjs.adMob.loadAppOpen("ca-app-pub-9295891708763537/8458521430", "", true, true);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BurgerMenuButton"), gdjs.MenuCode.GDBurgerMenuButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MenuCode.mapOfGDgdjs_9546MenuCode_9546GDBurgerMenuButtonObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Leaderboard", false);
}}

}


};

gdjs.MenuCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.MenuCode.GDFloatingOutButtonDarkBlueObjects1.length = 0;
gdjs.MenuCode.GDFloatingOutButtonDarkBlueObjects2.length = 0;
gdjs.MenuCode.GDFloatingOutButtonDarkBlue3Objects1.length = 0;
gdjs.MenuCode.GDFloatingOutButtonDarkBlue3Objects2.length = 0;
gdjs.MenuCode.GDFloatingOutButtonDarkBlue2Objects1.length = 0;
gdjs.MenuCode.GDFloatingOutButtonDarkBlue2Objects2.length = 0;
gdjs.MenuCode.GDTITLEObjects1.length = 0;
gdjs.MenuCode.GDTITLEObjects2.length = 0;
gdjs.MenuCode.GDFloatingOutButtonDarkBlue4Objects1.length = 0;
gdjs.MenuCode.GDFloatingOutButtonDarkBlue4Objects2.length = 0;
gdjs.MenuCode.GDFloatingOutButtonDarkBlue5Objects1.length = 0;
gdjs.MenuCode.GDFloatingOutButtonDarkBlue5Objects2.length = 0;
gdjs.MenuCode.GDGhostObjects1.length = 0;
gdjs.MenuCode.GDGhostObjects2.length = 0;
gdjs.MenuCode.GDLButtonObjects1.length = 0;
gdjs.MenuCode.GDLButtonObjects2.length = 0;
gdjs.MenuCode.GDBurgerMenuButtonObjects1.length = 0;
gdjs.MenuCode.GDBurgerMenuButtonObjects2.length = 0;

gdjs.MenuCode.eventsList0(runtimeScene);

return;

}

gdjs['MenuCode'] = gdjs.MenuCode;
