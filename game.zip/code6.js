gdjs.CreateCode = {};
gdjs.CreateCode.GDNewTextObjects1= [];
gdjs.CreateCode.GDNewTextObjects2= [];
gdjs.CreateCode.GDNewText2Objects1= [];
gdjs.CreateCode.GDNewText2Objects2= [];
gdjs.CreateCode.GDFloatingOutButtonDarkBlueObjects1= [];
gdjs.CreateCode.GDFloatingOutButtonDarkBlueObjects2= [];
gdjs.CreateCode.GDBlueButtonWithShadowObjects1= [];
gdjs.CreateCode.GDBlueButtonWithShadowObjects2= [];
gdjs.CreateCode.GDBlueButtonWithShadow2Objects1= [];
gdjs.CreateCode.GDBlueButtonWithShadow2Objects2= [];


gdjs.CreateCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("FloatingOutButtonDarkBlue"), gdjs.CreateCode.GDFloatingOutButtonDarkBlueObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.CreateCode.GDFloatingOutButtonDarkBlueObjects1.length;i<l;++i) {
    if ( gdjs.CreateCode.GDFloatingOutButtonDarkBlueObjects1[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.CreateCode.GDFloatingOutButtonDarkBlueObjects1[k] = gdjs.CreateCode.GDFloatingOutButtonDarkBlueObjects1[i];
        ++k;
    }
}
gdjs.CreateCode.GDFloatingOutButtonDarkBlueObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Multiplayer Lobby", false);
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.CreateCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.CreateCode.GDNewTextObjects1.length = 0;
gdjs.CreateCode.GDNewTextObjects2.length = 0;
gdjs.CreateCode.GDNewText2Objects1.length = 0;
gdjs.CreateCode.GDNewText2Objects2.length = 0;
gdjs.CreateCode.GDFloatingOutButtonDarkBlueObjects1.length = 0;
gdjs.CreateCode.GDFloatingOutButtonDarkBlueObjects2.length = 0;
gdjs.CreateCode.GDBlueButtonWithShadowObjects1.length = 0;
gdjs.CreateCode.GDBlueButtonWithShadowObjects2.length = 0;
gdjs.CreateCode.GDBlueButtonWithShadow2Objects1.length = 0;
gdjs.CreateCode.GDBlueButtonWithShadow2Objects2.length = 0;

gdjs.CreateCode.eventsList0(runtimeScene);

return;

}

gdjs['CreateCode'] = gdjs.CreateCode;
