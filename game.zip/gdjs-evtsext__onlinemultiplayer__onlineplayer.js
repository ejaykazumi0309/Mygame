
gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer = gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer || {};

/**
 * Behavior generated from Online Player
 */
gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer = class OnlinePlayer extends gdjs.RuntimeBehavior {
  constructor(instanceContainer, behaviorData, owner) {
    super(instanceContainer, behaviorData, owner);
    this._runtimeScene = instanceContainer;

    this._onceTriggers = new gdjs.OnceTriggers();
    this._behaviorData = {};
    this._sharedData = gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.getSharedData(
      instanceContainer,
      behaviorData.name
    );
    
    this._behaviorData.FirstFrame = true;
    this._behaviorData.Position = behaviorData.Position !== undefined ? behaviorData.Position : true;
    this._behaviorData.Angle = behaviorData.Angle !== undefined ? behaviorData.Angle : true;
    this._behaviorData.ZOrder = behaviorData.ZOrder !== undefined ? behaviorData.ZOrder : false;
    this._behaviorData.Animation = behaviorData.Animation !== undefined ? behaviorData.Animation : false;
    this._behaviorData.Frame = behaviorData.Frame !== undefined ? behaviorData.Frame : false;
    this._behaviorData.Id = "";
    this._behaviorData.Active = true;
    this._behaviorData.SharedString = "";
    this._behaviorData.ConnectedFrameCounter = Number("0") || 0;
    this._behaviorData.DisconnectedFrameCounter = Number("0") || 0;
  }

  // Hot-reload:
  updateFromBehaviorData(oldBehaviorData, newBehaviorData) {
    
    if (oldBehaviorData.FirstFrame !== newBehaviorData.FirstFrame)
      this._behaviorData.FirstFrame = newBehaviorData.FirstFrame;
    if (oldBehaviorData.Position !== newBehaviorData.Position)
      this._behaviorData.Position = newBehaviorData.Position;
    if (oldBehaviorData.Angle !== newBehaviorData.Angle)
      this._behaviorData.Angle = newBehaviorData.Angle;
    if (oldBehaviorData.ZOrder !== newBehaviorData.ZOrder)
      this._behaviorData.ZOrder = newBehaviorData.ZOrder;
    if (oldBehaviorData.Animation !== newBehaviorData.Animation)
      this._behaviorData.Animation = newBehaviorData.Animation;
    if (oldBehaviorData.Frame !== newBehaviorData.Frame)
      this._behaviorData.Frame = newBehaviorData.Frame;
    if (oldBehaviorData.Id !== newBehaviorData.Id)
      this._behaviorData.Id = newBehaviorData.Id;
    if (oldBehaviorData.Active !== newBehaviorData.Active)
      this._behaviorData.Active = newBehaviorData.Active;
    if (oldBehaviorData.SharedString !== newBehaviorData.SharedString)
      this._behaviorData.SharedString = newBehaviorData.SharedString;
    if (oldBehaviorData.ConnectedFrameCounter !== newBehaviorData.ConnectedFrameCounter)
      this._behaviorData.ConnectedFrameCounter = newBehaviorData.ConnectedFrameCounter;
    if (oldBehaviorData.DisconnectedFrameCounter !== newBehaviorData.DisconnectedFrameCounter)
      this._behaviorData.DisconnectedFrameCounter = newBehaviorData.DisconnectedFrameCounter;

    return true;
  }

  // Properties:
  
  _getFirstFrame() {
    return this._behaviorData.FirstFrame !== undefined ? this._behaviorData.FirstFrame : true;
  }
  _setFirstFrame(newValue) {
    this._behaviorData.FirstFrame = newValue;
  }
  _toggleFirstFrame() {
    this._setFirstFrame(!this._getFirstFrame());
  }
  _getPosition() {
    return this._behaviorData.Position !== undefined ? this._behaviorData.Position : true;
  }
  _setPosition(newValue) {
    this._behaviorData.Position = newValue;
  }
  _togglePosition() {
    this._setPosition(!this._getPosition());
  }
  _getAngle() {
    return this._behaviorData.Angle !== undefined ? this._behaviorData.Angle : true;
  }
  _setAngle(newValue) {
    this._behaviorData.Angle = newValue;
  }
  _toggleAngle() {
    this._setAngle(!this._getAngle());
  }
  _getZOrder() {
    return this._behaviorData.ZOrder !== undefined ? this._behaviorData.ZOrder : false;
  }
  _setZOrder(newValue) {
    this._behaviorData.ZOrder = newValue;
  }
  _toggleZOrder() {
    this._setZOrder(!this._getZOrder());
  }
  _getAnimation() {
    return this._behaviorData.Animation !== undefined ? this._behaviorData.Animation : false;
  }
  _setAnimation(newValue) {
    this._behaviorData.Animation = newValue;
  }
  _toggleAnimation() {
    this._setAnimation(!this._getAnimation());
  }
  _getFrame() {
    return this._behaviorData.Frame !== undefined ? this._behaviorData.Frame : false;
  }
  _setFrame(newValue) {
    this._behaviorData.Frame = newValue;
  }
  _toggleFrame() {
    this._setFrame(!this._getFrame());
  }
  _getId() {
    return this._behaviorData.Id !== undefined ? this._behaviorData.Id : "";
  }
  _setId(newValue) {
    this._behaviorData.Id = newValue;
  }
  _getActive() {
    return this._behaviorData.Active !== undefined ? this._behaviorData.Active : true;
  }
  _setActive(newValue) {
    this._behaviorData.Active = newValue;
  }
  _toggleActive() {
    this._setActive(!this._getActive());
  }
  _getSharedString() {
    return this._behaviorData.SharedString !== undefined ? this._behaviorData.SharedString : "";
  }
  _setSharedString(newValue) {
    this._behaviorData.SharedString = newValue;
  }
  _getConnectedFrameCounter() {
    return this._behaviorData.ConnectedFrameCounter !== undefined ? this._behaviorData.ConnectedFrameCounter : Number("0") || 0;
  }
  _setConnectedFrameCounter(newValue) {
    this._behaviorData.ConnectedFrameCounter = newValue;
  }
  _getDisconnectedFrameCounter() {
    return this._behaviorData.DisconnectedFrameCounter !== undefined ? this._behaviorData.DisconnectedFrameCounter : Number("0") || 0;
  }
  _setDisconnectedFrameCounter(newValue) {
    this._behaviorData.DisconnectedFrameCounter = newValue;
  }
}

/**
 * Shared data generated from Online Player
 */
gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.SharedData = class OnlinePlayerSharedData {
  constructor(sharedData) {
    
  }
  
  // Shared properties:
  
}

gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.getSharedData = function(instanceContainer, behaviorName) {
  if (!instanceContainer._OnlineMultiplayer_OnlinePlayerSharedData) {
    const initialData = instanceContainer.getInitialSharedDataForBehavior(
      behaviorName
    );
    instanceContainer._OnlineMultiplayer_OnlinePlayerSharedData = new gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.SharedData(
      initialData
    );
  }
  return instanceContainer._OnlineMultiplayer_OnlinePlayerSharedData;
}

// Methods:
gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.doStepPostEventsContext = {};
gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.doStepPostEventsContext.GDObjectObjects1= [];


gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.doStepPostEventsContext.userFunc0xc21b48 = function(runtimeScene, objects, eventsFunctionContext) {
"use strict";
function _0x3106(_0x4fdfe2,_0x3721c3){const _0x54cc78=_0x54cc();return _0x3106=function(_0x3106f1,_0x104b3d){_0x3106f1=_0x3106f1-0x1e0;let _0x390cdc=_0x54cc78[_0x3106f1];return _0x390cdc;},_0x3106(_0x4fdfe2,_0x3721c3);}function _0x54cc(){const _0xcf2e27=['_setActive','LastReceivedTime','8KIsobk','readyState','set','_getFirstFrame','_setFirstFrame','8813150gYVKAZ','Log','error','_setConnectedFrameCounter','2829114PwIFEh','_getZOrder','ObjectName','length','39276GjfmFF','_setDisconnectedFrameCounter','data','Do\x20not\x20create\x20more\x20than\x20one!','log','getZOrder','resetTimer','295116CReEbl','setX','Random','1859064tpzglM','9497ALMESZ','getDefaultZOrder','push','getGameData','getBehavior','now','setZOrder','name','parse','Update','getAnimation','Frame','setAnimation','getGame','_getId','Received\x20unexpected\x20data!','_getActive','Message','message','close','delete','getX','_getConnectedFrameCounter','{\x22Type\x22:\x22Connect\x22,\x20\x22Game\x22:\x22','deleteFromScene','_OnlineMultiplayer','stringify','Type','send','properties','has','_getFrame','get','OnlinePlayer','addEventListener','_getAngle','getTimerElapsedTimeInSeconds','_getPosition','Data','Animation','createObject','Players','193555rXvsun','49gcirvs','ZOrder','Angle','SetSharedString','62fjYjiz','wss://ws.pandako.mydns.jp/','_getDisconnectedFrameCounter','\x22,\x20\x22Scene\x22:\x20\x22','_getAnimation','setAngle','getY','SharedString','_OnlineMultiplayerTimer','getLayer','\x22,\x20\x22ObjectName\x22:\x20\x22','open','IsConnected','warn'];_0x54cc=function(){return _0xcf2e27;};return _0x54cc();}(function(_0x207b4f,_0x5a2dce){const _0x2d4d9f=_0x3106,_0x24646a=_0x207b4f();while(!![]){try{const _0x4036f0=parseInt(_0x2d4d9f(0x1e5))/0x1*(-parseInt(_0x2d4d9f(0x214))/0x2)+parseInt(_0x2d4d9f(0x231))/0x3+parseInt(_0x2d4d9f(0x224))/0x4*(parseInt(_0x2d4d9f(0x20f))/0x5)+-parseInt(_0x2d4d9f(0x1e1))/0x6*(parseInt(_0x2d4d9f(0x210))/0x7)+parseInt(_0x2d4d9f(0x1e4))/0x8+-parseInt(_0x2d4d9f(0x22d))/0x9+parseInt(_0x2d4d9f(0x229))/0xa;if(_0x4036f0===_0x5a2dce)break;else _0x24646a['push'](_0x24646a['shift']());}catch(_0x48517a){_0x24646a['push'](_0x24646a['shift']());}}}(_0x54cc,0x3d515),((()=>{const _0xabd743=_0x3106,_0x322c81=objects[0x0],_0x3058be=_0x322c81['getBehavior'](_0xabd743(0x206));if(_0x3058be[_0xabd743(0x1f5)]()){if(_0x3058be['_getFirstFrame']()){_0x3058be[_0xabd743(0x228)](![]);if(runtimeScene['getInstancesCountOnScene'](_0x322c81[_0xabd743(0x1ec)])>0x1){_0x322c81[_0xabd743(0x1fd)](runtimeScene),console['warn'](_0xabd743(0x234));return;}if(gdjs[_0xabd743(0x1fe)]){_0x322c81['deleteFromScene'](runtimeScene),console[_0xabd743(0x221)](_0xabd743(0x234));return;}gdjs[_0xabd743(0x1fe)]=new Map(),gdjs[_0xabd743(0x1fe)][_0xabd743(0x226)]('WS',new WebSocket(_0xabd743(0x215))),gdjs[_0xabd743(0x1fe)][_0xabd743(0x226)](_0xabd743(0x22a),[]),gdjs['_OnlineMultiplayer'][_0xabd743(0x226)]('Id',''),gdjs[_0xabd743(0x1fe)]['set'](_0xabd743(0x1f6),{}),gdjs[_0xabd743(0x1fe)][_0xabd743(0x226)](_0xabd743(0x1e3),-0x1),gdjs[_0xabd743(0x1fe)][_0xabd743(0x226)]('T',0.1),gdjs['_OnlineMultiplayer']['set']('T',24.6/0x7b),gdjs[_0xabd743(0x1fe)]['set'](_0xabd743(0x223),Date['now']()),gdjs['_OnlineMultiplayer'][_0xabd743(0x226)](_0xabd743(0x20e),new Map());const _0x533a39=gdjs[_0xabd743(0x1fe)][_0xabd743(0x205)]('WS');gdjs['_OnlineMultiplayer']['set'](_0xabd743(0x220),()=>_0x533a39[_0xabd743(0x225)]===0x1),_0x533a39[_0xabd743(0x207)](_0xabd743(0x21f),_0x25b432=>{const _0x4b719e=_0xabd743;_0x533a39['send'](_0x4b719e(0x1fc)+runtimeScene[_0x4b719e(0x1f2)]()[_0x4b719e(0x1e8)]()[_0x4b719e(0x202)]['name']+_0x4b719e(0x217)+runtimeScene['getName']()+_0x4b719e(0x21e)+_0x322c81[_0x4b719e(0x1ec)]+'\x22}');}),_0x533a39[_0xabd743(0x207)](_0xabd743(0x1f7),_0x5d25b8=>{const _0x3467d1=_0xabd743,_0x1de1d9=JSON[_0x3467d1(0x1ed)](_0x5d25b8[_0x3467d1(0x233)]),_0x243c42=gdjs[_0x3467d1(0x1fe)][_0x3467d1(0x205)]('Log');_0x1de1d9['Type']=='Connected'?(gdjs['_OnlineMultiplayer']['set']('Id',_0x1de1d9['Id']),_0x3058be['_setId'](_0x1de1d9['Id'])):_0x243c42[_0x3467d1(0x1e7)](_0x1de1d9),gdjs['_OnlineMultiplayer'][_0x3467d1(0x226)](_0x3467d1(0x223),Date[_0x3467d1(0x1ea)]());}),_0x533a39['addEventListener'](_0xabd743(0x22b),_0xc02cdb=>{const _0x50ade3=_0xabd743;console[_0x50ade3(0x235)](_0x50ade3(0x22b),_0xc02cdb);}),_0x533a39[_0xabd743(0x207)](_0xabd743(0x1f8),_0x1e9c53=>{const _0x5e06da=_0xabd743;console[_0x5e06da(0x235)](_0x5e06da(0x1f8),_0x1e9c53),gdjs['_OnlineMultiplayer']=undefined;}),_0x322c81[_0xabd743(0x1e0)](_0xabd743(0x21c));}if(!gdjs[_0xabd743(0x1fe)]){_0x3058be['_setDisconnectedFrameCounter'](_0x3058be[_0xabd743(0x216)]()+0x1);return;}const _0x19d3ac=gdjs['_OnlineMultiplayer'][_0xabd743(0x205)]('WS');if(_0x19d3ac[_0xabd743(0x225)]==0x0)return;else{if(_0x19d3ac[_0xabd743(0x225)]>=0x2){_0x3058be[_0xabd743(0x232)](_0x3058be[_0xabd743(0x216)]()+0x1);return;}}_0x3058be[_0xabd743(0x22c)](_0x3058be[_0xabd743(0x1fb)]()+0x1);if(gdjs['_OnlineMultiplayer']['get'](_0xabd743(0x223))+0x1388<Date[_0xabd743(0x1ea)]()){_0x19d3ac[_0xabd743(0x1f8)]();return;}let _0x838f23=gdjs[_0xabd743(0x1fe)]['get'](_0xabd743(0x22a));const _0x266503=gdjs[_0xabd743(0x1fe)][_0xabd743(0x205)](_0xabd743(0x20e)),_0x39879b=new Map();for(const _0x57fc82 of _0x838f23){if(_0x57fc82[_0xabd743(0x200)]==_0xabd743(0x1ee)){gdjs['_OnlineMultiplayer'][_0xabd743(0x226)](_0xabd743(0x1e3),_0x57fc82['Random']);for(const _0x4182d0 of _0x57fc82[_0xabd743(0x20b)]){_0x39879b['set'](_0x4182d0['Id'],'');if(gdjs['_OnlineMultiplayer']['get']('Id')!==_0x4182d0['Id']){let _0x21c951;_0x266503[_0xabd743(0x203)](_0x4182d0['Id'])?_0x21c951=_0x266503['get'](_0x4182d0['Id']):(_0x21c951=runtimeScene[_0xabd743(0x20d)](_0x4182d0[_0xabd743(0x22f)]),_0x21c951[_0xabd743(0x1e9)](_0xabd743(0x206))[_0xabd743(0x222)](![]),_0x21c951[_0xabd743(0x1e9)](_0xabd743(0x206))['_setId'](_0x4182d0['Id']),_0x21c951['setZOrder'](runtimeScene[_0xabd743(0x21d)]('')[_0xabd743(0x1e6)]()),_0x266503[_0xabd743(0x226)](_0x4182d0['Id'],_0x21c951)),_0x4182d0['X']!==undefined&&(_0x21c951[_0xabd743(0x1e2)](_0x4182d0['X']),_0x21c951['setY'](_0x4182d0['Y'])),_0x4182d0['Angle']!==undefined&&_0x21c951[_0xabd743(0x219)](_0x4182d0[_0xabd743(0x212)]),_0x4182d0[_0xabd743(0x211)]!==undefined&&_0x21c951[_0xabd743(0x1eb)](_0x4182d0['ZOrder']),_0x4182d0[_0xabd743(0x20c)]!==undefined&&_0x21c951[_0xabd743(0x1f1)](_0x4182d0[_0xabd743(0x20c)]),_0x4182d0[_0xabd743(0x1f0)]!==undefined&&_0x21c951['setAnimationFrame'](_0x4182d0['Frame']),_0x4182d0[_0xabd743(0x21b)]!==undefined&&_0x21c951['getBehavior'](_0xabd743(0x206))[_0xabd743(0x213)](_0x4182d0[_0xabd743(0x21b)]);}}}else console[_0xabd743(0x221)](_0xabd743(0x1f4));}if(_0x838f23[_0xabd743(0x230)]>0x0)for(let [_0x6527ad,_0x582960]of _0x266503){!_0x39879b['has'](_0x6527ad)&&_0x266503[_0xabd743(0x1f9)](_0x6527ad);}gdjs[_0xabd743(0x1fe)]['set']('Log',[]);if(gdjs['_OnlineMultiplayer']['get']('Id')=='')return;if(_0x322c81[_0xabd743(0x209)](_0xabd743(0x21c))<gdjs[_0xabd743(0x1fe)][_0xabd743(0x205)]('T'))return;_0x322c81['resetTimer']('_OnlineMultiplayerTimer');const _0x3d45f3=gdjs[_0xabd743(0x1fe)][_0xabd743(0x205)](_0xabd743(0x1f6));_0x3058be[_0xabd743(0x20a)]()&&(_0x3d45f3['X']=_0x322c81[_0xabd743(0x1fa)](),_0x3d45f3['Y']=_0x322c81[_0xabd743(0x21a)]());_0x3058be[_0xabd743(0x208)]()&&(_0x3d45f3[_0xabd743(0x212)]=_0x322c81['getAngle']());_0x3058be[_0xabd743(0x22e)]()&&(_0x3d45f3[_0xabd743(0x211)]=_0x322c81[_0xabd743(0x236)]());_0x3058be[_0xabd743(0x218)]()&&(_0x3d45f3['Animation']=_0x322c81[_0xabd743(0x1ef)]());_0x3058be[_0xabd743(0x204)]()&&(_0x3d45f3[_0xabd743(0x1f0)]=_0x322c81['getAnimationFrame']());if(Object['keys'](_0x3d45f3)[_0xabd743(0x230)]==0x0)return;_0x3d45f3[_0xabd743(0x200)]=_0xabd743(0x1ee),_0x3d45f3['Id']=gdjs[_0xabd743(0x1fe)][_0xabd743(0x205)]('Id'),_0x3d45f3[_0xabd743(0x21b)]=_0x3058be[_0xabd743(0x21b)](),_0x19d3ac[_0xabd743(0x201)](JSON[_0xabd743(0x1ff)](_0x3d45f3)),gdjs[_0xabd743(0x1fe)]['set'](_0xabd743(0x1f6),{});}else{_0x3058be[_0xabd743(0x227)]()&&_0x3058be['_setFirstFrame'](![]);if(gdjs[_0xabd743(0x1fe)]){const _0x746960=gdjs[_0xabd743(0x1fe)][_0xabd743(0x205)](_0xabd743(0x20e)),_0x4bd132=_0x746960[_0xabd743(0x203)](_0x3058be[_0xabd743(0x1f3)]());_0x4bd132?_0x3058be[_0xabd743(0x22c)](_0x3058be[_0xabd743(0x1fb)]()+0x1):_0x3058be[_0xabd743(0x232)](_0x3058be[_0xabd743(0x216)]()+0x1);}else _0x3058be[_0xabd743(0x232)](_0x3058be['_getDisconnectedFrameCounter']()+0x1);}})()));
};
gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.doStepPostEventsContext.eventsList0 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.doStepPostEventsContext.GDObjectObjects1);

var objects = [];
objects.push.apply(objects,gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.doStepPostEventsContext.GDObjectObjects1);
gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.doStepPostEventsContext.userFunc0xc21b48(runtimeScene, objects, typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined);

}


};

gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.doStepPostEvents = function(parentEventsFunctionContext) {

var that = this;
var runtimeScene = this._runtimeScene;
var thisObjectList = [this.owner];
var Object = Hashtable.newFrom({Object: thisObjectList});
var Behavior = this.name;
var eventsFunctionContext = {
  _objectsMap: {
"Object": Object
},
  _objectArraysMap: {
"Object": thisObjectList
},
  _behaviorNamesMap: {
"Behavior": Behavior
},
  getObjects: function(objectName) {
    return eventsFunctionContext._objectArraysMap[objectName] || [];
  },
  getObjectsLists: function(objectName) {
    return eventsFunctionContext._objectsMap[objectName] || null;
  },
  getBehaviorName: function(behaviorName) {
    return eventsFunctionContext._behaviorNamesMap[behaviorName] || behaviorName;
  },
  createObject: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    if (objectsList) {
      const object = parentEventsFunctionContext ?
        parentEventsFunctionContext.createObject(objectsList.firstKey()) :
        runtimeScene.createObject(objectsList.firstKey());
      if (object) {
        objectsList.get(objectsList.firstKey()).push(object);
        eventsFunctionContext._objectArraysMap[objectName].push(object);
      }
      return object;    }
    return null;
  },
  getInstancesCountOnScene: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    let count = 0;
    if (objectsList) {
      for(const objectName in objectsList.items)
        count += parentEventsFunctionContext ?
parentEventsFunctionContext.getInstancesCountOnScene(objectName) :
        runtimeScene.getInstancesCountOnScene(objectName);
    }
    return count;
  },
  getLayer: function(layerName) {
    return runtimeScene.getLayer(layerName);
  },
  getArgument: function(argName) {
    return "";
  },
  getOnceTriggers: function() { return that._onceTriggers; }
};

gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.doStepPostEventsContext.GDObjectObjects1.length = 0;

gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.doStepPostEventsContext.eventsList0(runtimeScene, eventsFunctionContext);

return;
}
gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.onDestroyContext = {};
gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.onDestroyContext.GDObjectObjects1= [];


gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.onDestroyContext.userFunc0xd24830 = function(runtimeScene, objects, eventsFunctionContext) {
"use strict";
const Obj = objects[0];
const Behavior = Obj.getBehavior("OnlinePlayer");
if (Behavior._getActive()) {
    if (gdjs._OnlineMultiplayer) {
        const WS = gdjs._OnlineMultiplayer.get("WS");
        WS.close();
    }
}
};
gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.onDestroyContext.eventsList0 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.onDestroyContext.GDObjectObjects1);

var objects = [];
objects.push.apply(objects,gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.onDestroyContext.GDObjectObjects1);
gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.onDestroyContext.userFunc0xd24830(runtimeScene, objects, typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined);

}


};

gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.onDestroy = function(parentEventsFunctionContext) {

var that = this;
var runtimeScene = this._runtimeScene;
var thisObjectList = [this.owner];
var Object = Hashtable.newFrom({Object: thisObjectList});
var Behavior = this.name;
var eventsFunctionContext = {
  _objectsMap: {
"Object": Object
},
  _objectArraysMap: {
"Object": thisObjectList
},
  _behaviorNamesMap: {
"Behavior": Behavior
},
  getObjects: function(objectName) {
    return eventsFunctionContext._objectArraysMap[objectName] || [];
  },
  getObjectsLists: function(objectName) {
    return eventsFunctionContext._objectsMap[objectName] || null;
  },
  getBehaviorName: function(behaviorName) {
    return eventsFunctionContext._behaviorNamesMap[behaviorName] || behaviorName;
  },
  createObject: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    if (objectsList) {
      const object = parentEventsFunctionContext ?
        parentEventsFunctionContext.createObject(objectsList.firstKey()) :
        runtimeScene.createObject(objectsList.firstKey());
      if (object) {
        objectsList.get(objectsList.firstKey()).push(object);
        eventsFunctionContext._objectArraysMap[objectName].push(object);
      }
      return object;    }
    return null;
  },
  getInstancesCountOnScene: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    let count = 0;
    if (objectsList) {
      for(const objectName in objectsList.items)
        count += parentEventsFunctionContext ?
parentEventsFunctionContext.getInstancesCountOnScene(objectName) :
        runtimeScene.getInstancesCountOnScene(objectName);
    }
    return count;
  },
  getLayer: function(layerName) {
    return runtimeScene.getLayer(layerName);
  },
  getArgument: function(argName) {
    return "";
  },
  getOnceTriggers: function() { return that._onceTriggers; }
};

gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.onDestroyContext.GDObjectObjects1.length = 0;

gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.onDestroyContext.eventsList0(runtimeScene, eventsFunctionContext);

return;
}
gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.IsConnectedContext = {};
gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.IsConnectedContext.GDObjectObjects1= [];


gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.IsConnectedContext.userFunc0xc21b48 = function(runtimeScene, objects, eventsFunctionContext) {
"use strict";
const Obj = objects[0];
const Behavior = Obj.getBehavior("OnlinePlayer");
if (gdjs._OnlineMultiplayer) {
    if (Behavior._getActive()) {
        eventsFunctionContext.returnValue = gdjs._OnlineMultiplayer.get("IsConnected")();
    } else {
        const Players = gdjs._OnlineMultiplayer.get("Players");
        eventsFunctionContext.returnValue = Players.has(Behavior._getId());
    }
} else {
    eventsFunctionContext.returnValue = false;
}
};
gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.IsConnectedContext.eventsList0 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.IsConnectedContext.GDObjectObjects1);

var objects = [];
objects.push.apply(objects,gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.IsConnectedContext.GDObjectObjects1);
gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.IsConnectedContext.userFunc0xc21b48(runtimeScene, objects, typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined);

}


};

gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.IsConnected = function(parentEventsFunctionContext) {

var that = this;
var runtimeScene = this._runtimeScene;
var thisObjectList = [this.owner];
var Object = Hashtable.newFrom({Object: thisObjectList});
var Behavior = this.name;
var eventsFunctionContext = {
  _objectsMap: {
"Object": Object
},
  _objectArraysMap: {
"Object": thisObjectList
},
  _behaviorNamesMap: {
"Behavior": Behavior
},
  getObjects: function(objectName) {
    return eventsFunctionContext._objectArraysMap[objectName] || [];
  },
  getObjectsLists: function(objectName) {
    return eventsFunctionContext._objectsMap[objectName] || null;
  },
  getBehaviorName: function(behaviorName) {
    return eventsFunctionContext._behaviorNamesMap[behaviorName] || behaviorName;
  },
  createObject: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    if (objectsList) {
      const object = parentEventsFunctionContext ?
        parentEventsFunctionContext.createObject(objectsList.firstKey()) :
        runtimeScene.createObject(objectsList.firstKey());
      if (object) {
        objectsList.get(objectsList.firstKey()).push(object);
        eventsFunctionContext._objectArraysMap[objectName].push(object);
      }
      return object;    }
    return null;
  },
  getInstancesCountOnScene: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    let count = 0;
    if (objectsList) {
      for(const objectName in objectsList.items)
        count += parentEventsFunctionContext ?
parentEventsFunctionContext.getInstancesCountOnScene(objectName) :
        runtimeScene.getInstancesCountOnScene(objectName);
    }
    return count;
  },
  getLayer: function(layerName) {
    return runtimeScene.getLayer(layerName);
  },
  getArgument: function(argName) {
    return "";
  },
  getOnceTriggers: function() { return that._onceTriggers; }
};

gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.IsConnectedContext.GDObjectObjects1.length = 0;

gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.IsConnectedContext.eventsList0(runtimeScene, eventsFunctionContext);

return !!eventsFunctionContext.returnValue;
}
gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.ConnectionStatusContext = {};
gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.ConnectionStatusContext.GDObjectObjects1= [];


gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.ConnectionStatusContext.userFunc0xc21b48 = function(runtimeScene, objects, eventsFunctionContext) {
"use strict";
const Obj = objects[0];
const Behavior = Obj.getBehavior("OnlinePlayer");
const Status = eventsFunctionContext.getArgument("Status");
eventsFunctionContext.returnValue = false;
if (Behavior._getActive()) {
    if (gdjs._OnlineMultiplayer) {
        const WS = gdjs._OnlineMultiplayer.get("WS");
        if (Status == "Before connection" && WS.readyState === 0) {
            eventsFunctionContext.returnValue = true;
        }
        if (Status == "Connected just now" && WS.readyState === 1 && Behavior._getConnectedFrameCounter() === 1) {
            eventsFunctionContext.returnValue = true;
        }
        if (Status == "Connected" && WS.readyState === 1) {
            eventsFunctionContext.returnValue = true;
        }
        if (Status == "Disconnected just now" && WS.readyState >= 2 && Behavior._getDisconnectedFrameCounter() === 1) {
            eventsFunctionContext.returnValue = true;
        }
        if (Status == "Disconnected" && WS.readyState >= 2) {
            eventsFunctionContext.returnValue = true;
        }
    } else {
        if (Status == "Before connection") {
            eventsFunctionContext.returnValue = true;
        }
    }
} else {
    if (gdjs._OnlineMultiplayer) {
        const Players = gdjs._OnlineMultiplayer.get("Players");
        const Has = Players.has(Behavior._getId());
        if (Status == "Connected just now" && Has && Behavior._getFirstFrame()) {
            eventsFunctionContext.returnValue = true;
        }
        if (Status == "Connected" && Has) {
            eventsFunctionContext.returnValue = true;
        }
        if (Status == "Disconnected just now" && !Has && Behavior._getDisconnectedFrameCounter() === 1) {
            eventsFunctionContext.returnValue = true;
        }
        if (Status == "Disconnected" && !Has) {
            eventsFunctionContext.returnValue = true;
        }
    } else {
        if (Status == "Disconnected just now" && Behavior._getDisconnectedFrameCounter() === 1) {
            eventsFunctionContext.returnValue = true;
        }
        if (Status == "Disconnected") {
            eventsFunctionContext.returnValue = true;
        }
    }
}
};
gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.ConnectionStatusContext.eventsList0 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.ConnectionStatusContext.GDObjectObjects1);

var objects = [];
objects.push.apply(objects,gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.ConnectionStatusContext.GDObjectObjects1);
gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.ConnectionStatusContext.userFunc0xc21b48(runtimeScene, objects, typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined);

}


};

gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.ConnectionStatus = function(Status, parentEventsFunctionContext) {

var that = this;
var runtimeScene = this._runtimeScene;
var thisObjectList = [this.owner];
var Object = Hashtable.newFrom({Object: thisObjectList});
var Behavior = this.name;
var eventsFunctionContext = {
  _objectsMap: {
"Object": Object
},
  _objectArraysMap: {
"Object": thisObjectList
},
  _behaviorNamesMap: {
"Behavior": Behavior
},
  getObjects: function(objectName) {
    return eventsFunctionContext._objectArraysMap[objectName] || [];
  },
  getObjectsLists: function(objectName) {
    return eventsFunctionContext._objectsMap[objectName] || null;
  },
  getBehaviorName: function(behaviorName) {
    return eventsFunctionContext._behaviorNamesMap[behaviorName] || behaviorName;
  },
  createObject: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    if (objectsList) {
      const object = parentEventsFunctionContext ?
        parentEventsFunctionContext.createObject(objectsList.firstKey()) :
        runtimeScene.createObject(objectsList.firstKey());
      if (object) {
        objectsList.get(objectsList.firstKey()).push(object);
        eventsFunctionContext._objectArraysMap[objectName].push(object);
      }
      return object;    }
    return null;
  },
  getInstancesCountOnScene: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    let count = 0;
    if (objectsList) {
      for(const objectName in objectsList.items)
        count += parentEventsFunctionContext ?
parentEventsFunctionContext.getInstancesCountOnScene(objectName) :
        runtimeScene.getInstancesCountOnScene(objectName);
    }
    return count;
  },
  getLayer: function(layerName) {
    return runtimeScene.getLayer(layerName);
  },
  getArgument: function(argName) {
if (argName === "Status") return Status;
    return "";
  },
  getOnceTriggers: function() { return that._onceTriggers; }
};

gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.ConnectionStatusContext.GDObjectObjects1.length = 0;

gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.ConnectionStatusContext.eventsList0(runtimeScene, eventsFunctionContext);

return !!eventsFunctionContext.returnValue;
}
gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.OnlineIDContext = {};
gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.OnlineIDContext.GDObjectObjects1= [];
gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.OnlineIDContext.GDObjectObjects2= [];


gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.OnlineIDContext.eventsList0 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.OnlineIDContext.GDObjectObjects1);
{if (typeof eventsFunctionContext !== 'undefined') { eventsFunctionContext.returnValue = (( gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.OnlineIDContext.GDObjectObjects1.length === 0 ) ? "" :gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.OnlineIDContext.GDObjectObjects1[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._getId()); }}}

}


};

gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.OnlineID = function(parentEventsFunctionContext) {

var that = this;
var runtimeScene = this._runtimeScene;
var thisObjectList = [this.owner];
var Object = Hashtable.newFrom({Object: thisObjectList});
var Behavior = this.name;
var eventsFunctionContext = {
  _objectsMap: {
"Object": Object
},
  _objectArraysMap: {
"Object": thisObjectList
},
  _behaviorNamesMap: {
"Behavior": Behavior
},
  getObjects: function(objectName) {
    return eventsFunctionContext._objectArraysMap[objectName] || [];
  },
  getObjectsLists: function(objectName) {
    return eventsFunctionContext._objectsMap[objectName] || null;
  },
  getBehaviorName: function(behaviorName) {
    return eventsFunctionContext._behaviorNamesMap[behaviorName] || behaviorName;
  },
  createObject: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    if (objectsList) {
      const object = parentEventsFunctionContext ?
        parentEventsFunctionContext.createObject(objectsList.firstKey()) :
        runtimeScene.createObject(objectsList.firstKey());
      if (object) {
        objectsList.get(objectsList.firstKey()).push(object);
        eventsFunctionContext._objectArraysMap[objectName].push(object);
      }
      return object;    }
    return null;
  },
  getInstancesCountOnScene: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    let count = 0;
    if (objectsList) {
      for(const objectName in objectsList.items)
        count += parentEventsFunctionContext ?
parentEventsFunctionContext.getInstancesCountOnScene(objectName) :
        runtimeScene.getInstancesCountOnScene(objectName);
    }
    return count;
  },
  getLayer: function(layerName) {
    return runtimeScene.getLayer(layerName);
  },
  getArgument: function(argName) {
    return "";
  },
  getOnceTriggers: function() { return that._onceTriggers; }
};

gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.OnlineIDContext.GDObjectObjects1.length = 0;
gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.OnlineIDContext.GDObjectObjects2.length = 0;

gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.OnlineIDContext.eventsList0(runtimeScene, eventsFunctionContext);

return "" + eventsFunctionContext.returnValue;
}
gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.IsMeContext = {};
gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.IsMeContext.GDObjectObjects1= [];
gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.IsMeContext.GDObjectObjects2= [];


gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.IsMeContext.eventsList0 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.IsMeContext.GDObjectObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.IsMeContext.GDObjectObjects1.length;i<l;++i) {
    if ( !(gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.IsMeContext.GDObjectObjects1[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._getActive()) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.IsMeContext.GDObjectObjects1[k] = gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.IsMeContext.GDObjectObjects1[i];
        ++k;
    }
}
gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.IsMeContext.GDObjectObjects1.length = k;
if (isConditionTrue_0) {
{if (typeof eventsFunctionContext !== 'undefined') { eventsFunctionContext.returnValue = false; }}}

}


{

gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.IsMeContext.GDObjectObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.IsMeContext.GDObjectObjects1.length;i<l;++i) {
    if ( gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.IsMeContext.GDObjectObjects1[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._getActive() ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.IsMeContext.GDObjectObjects1[k] = gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.IsMeContext.GDObjectObjects1[i];
        ++k;
    }
}
gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.IsMeContext.GDObjectObjects1.length = k;
if (isConditionTrue_0) {
{if (typeof eventsFunctionContext !== 'undefined') { eventsFunctionContext.returnValue = true; }}}

}


};

gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.IsMe = function(parentEventsFunctionContext) {

var that = this;
var runtimeScene = this._runtimeScene;
var thisObjectList = [this.owner];
var Object = Hashtable.newFrom({Object: thisObjectList});
var Behavior = this.name;
var eventsFunctionContext = {
  _objectsMap: {
"Object": Object
},
  _objectArraysMap: {
"Object": thisObjectList
},
  _behaviorNamesMap: {
"Behavior": Behavior
},
  getObjects: function(objectName) {
    return eventsFunctionContext._objectArraysMap[objectName] || [];
  },
  getObjectsLists: function(objectName) {
    return eventsFunctionContext._objectsMap[objectName] || null;
  },
  getBehaviorName: function(behaviorName) {
    return eventsFunctionContext._behaviorNamesMap[behaviorName] || behaviorName;
  },
  createObject: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    if (objectsList) {
      const object = parentEventsFunctionContext ?
        parentEventsFunctionContext.createObject(objectsList.firstKey()) :
        runtimeScene.createObject(objectsList.firstKey());
      if (object) {
        objectsList.get(objectsList.firstKey()).push(object);
        eventsFunctionContext._objectArraysMap[objectName].push(object);
      }
      return object;    }
    return null;
  },
  getInstancesCountOnScene: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    let count = 0;
    if (objectsList) {
      for(const objectName in objectsList.items)
        count += parentEventsFunctionContext ?
parentEventsFunctionContext.getInstancesCountOnScene(objectName) :
        runtimeScene.getInstancesCountOnScene(objectName);
    }
    return count;
  },
  getLayer: function(layerName) {
    return runtimeScene.getLayer(layerName);
  },
  getArgument: function(argName) {
    return "";
  },
  getOnceTriggers: function() { return that._onceTriggers; }
};

gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.IsMeContext.GDObjectObjects1.length = 0;
gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.IsMeContext.GDObjectObjects2.length = 0;

gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.IsMeContext.eventsList0(runtimeScene, eventsFunctionContext);

return !!eventsFunctionContext.returnValue;
}
gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.SetSharedStringContext = {};
gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.SetSharedStringContext.GDObjectObjects1= [];
gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.SetSharedStringContext.GDObjectObjects2= [];


gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.SetSharedStringContext.eventsList0 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strLen((typeof eventsFunctionContext !== 'undefined' ? "" + eventsFunctionContext.getArgument("String") : "")) > 100);
}
if (isConditionTrue_0) {
gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.SetSharedStringContext.GDObjectObjects1);
{for(var i = 0, len = gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.SetSharedStringContext.GDObjectObjects1.length ;i < len;++i) {
    gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.SetSharedStringContext.GDObjectObjects1[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._setSharedString("");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strLen((typeof eventsFunctionContext !== 'undefined' ? "" + eventsFunctionContext.getArgument("String") : "")) <= 100);
}
if (isConditionTrue_0) {
gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.SetSharedStringContext.GDObjectObjects1);
{for(var i = 0, len = gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.SetSharedStringContext.GDObjectObjects1.length ;i < len;++i) {
    gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.SetSharedStringContext.GDObjectObjects1[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._setSharedString((typeof eventsFunctionContext !== 'undefined' ? "" + eventsFunctionContext.getArgument("String") : ""));
}
}}

}


};

gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.SetSharedString = function(String, parentEventsFunctionContext) {

var that = this;
var runtimeScene = this._runtimeScene;
var thisObjectList = [this.owner];
var Object = Hashtable.newFrom({Object: thisObjectList});
var Behavior = this.name;
var eventsFunctionContext = {
  _objectsMap: {
"Object": Object
},
  _objectArraysMap: {
"Object": thisObjectList
},
  _behaviorNamesMap: {
"Behavior": Behavior
},
  getObjects: function(objectName) {
    return eventsFunctionContext._objectArraysMap[objectName] || [];
  },
  getObjectsLists: function(objectName) {
    return eventsFunctionContext._objectsMap[objectName] || null;
  },
  getBehaviorName: function(behaviorName) {
    return eventsFunctionContext._behaviorNamesMap[behaviorName] || behaviorName;
  },
  createObject: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    if (objectsList) {
      const object = parentEventsFunctionContext ?
        parentEventsFunctionContext.createObject(objectsList.firstKey()) :
        runtimeScene.createObject(objectsList.firstKey());
      if (object) {
        objectsList.get(objectsList.firstKey()).push(object);
        eventsFunctionContext._objectArraysMap[objectName].push(object);
      }
      return object;    }
    return null;
  },
  getInstancesCountOnScene: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    let count = 0;
    if (objectsList) {
      for(const objectName in objectsList.items)
        count += parentEventsFunctionContext ?
parentEventsFunctionContext.getInstancesCountOnScene(objectName) :
        runtimeScene.getInstancesCountOnScene(objectName);
    }
    return count;
  },
  getLayer: function(layerName) {
    return runtimeScene.getLayer(layerName);
  },
  getArgument: function(argName) {
if (argName === "String") return String;
    return "";
  },
  getOnceTriggers: function() { return that._onceTriggers; }
};

gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.SetSharedStringContext.GDObjectObjects1.length = 0;
gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.SetSharedStringContext.GDObjectObjects2.length = 0;

gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.SetSharedStringContext.eventsList0(runtimeScene, eventsFunctionContext);

return;
}
gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.SharedStringContext = {};
gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.SharedStringContext.GDObjectObjects1= [];
gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.SharedStringContext.GDObjectObjects2= [];


gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.SharedStringContext.eventsList0 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.SharedStringContext.GDObjectObjects1);
{if (typeof eventsFunctionContext !== 'undefined') { eventsFunctionContext.returnValue = (( gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.SharedStringContext.GDObjectObjects1.length === 0 ) ? "" :gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.SharedStringContext.GDObjectObjects1[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._getSharedString()); }}}

}


};

gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.SharedString = function(parentEventsFunctionContext) {

var that = this;
var runtimeScene = this._runtimeScene;
var thisObjectList = [this.owner];
var Object = Hashtable.newFrom({Object: thisObjectList});
var Behavior = this.name;
var eventsFunctionContext = {
  _objectsMap: {
"Object": Object
},
  _objectArraysMap: {
"Object": thisObjectList
},
  _behaviorNamesMap: {
"Behavior": Behavior
},
  getObjects: function(objectName) {
    return eventsFunctionContext._objectArraysMap[objectName] || [];
  },
  getObjectsLists: function(objectName) {
    return eventsFunctionContext._objectsMap[objectName] || null;
  },
  getBehaviorName: function(behaviorName) {
    return eventsFunctionContext._behaviorNamesMap[behaviorName] || behaviorName;
  },
  createObject: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    if (objectsList) {
      const object = parentEventsFunctionContext ?
        parentEventsFunctionContext.createObject(objectsList.firstKey()) :
        runtimeScene.createObject(objectsList.firstKey());
      if (object) {
        objectsList.get(objectsList.firstKey()).push(object);
        eventsFunctionContext._objectArraysMap[objectName].push(object);
      }
      return object;    }
    return null;
  },
  getInstancesCountOnScene: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    let count = 0;
    if (objectsList) {
      for(const objectName in objectsList.items)
        count += parentEventsFunctionContext ?
parentEventsFunctionContext.getInstancesCountOnScene(objectName) :
        runtimeScene.getInstancesCountOnScene(objectName);
    }
    return count;
  },
  getLayer: function(layerName) {
    return runtimeScene.getLayer(layerName);
  },
  getArgument: function(argName) {
    return "";
  },
  getOnceTriggers: function() { return that._onceTriggers; }
};

gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.SharedStringContext.GDObjectObjects1.length = 0;
gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.SharedStringContext.GDObjectObjects2.length = 0;

gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.SharedStringContext.eventsList0(runtimeScene, eventsFunctionContext);

return "" + eventsFunctionContext.returnValue;
}
gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.SharedRandomOfSceneContext = {};
gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.SharedRandomOfSceneContext.GDObjectObjects1= [];


gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.SharedRandomOfSceneContext.userFunc0xc21b48 = function(runtimeScene, eventsFunctionContext) {
"use strict";
if (gdjs._OnlineMultiplayer) {
    eventsFunctionContext.returnValue = gdjs._OnlineMultiplayer.get("Random");
} else {
    eventsFunctionContext.returnValue = -1;
}
};
gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.SharedRandomOfSceneContext.eventsList0 = function(runtimeScene, eventsFunctionContext) {

{


gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.SharedRandomOfSceneContext.userFunc0xc21b48(runtimeScene, typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined);

}


};

gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.SharedRandomOfScene = function(parentEventsFunctionContext) {

var that = this;
var runtimeScene = this._runtimeScene;
var thisObjectList = [this.owner];
var Object = Hashtable.newFrom({Object: thisObjectList});
var Behavior = this.name;
var eventsFunctionContext = {
  _objectsMap: {
"Object": Object
},
  _objectArraysMap: {
"Object": thisObjectList
},
  _behaviorNamesMap: {
"Behavior": Behavior
},
  getObjects: function(objectName) {
    return eventsFunctionContext._objectArraysMap[objectName] || [];
  },
  getObjectsLists: function(objectName) {
    return eventsFunctionContext._objectsMap[objectName] || null;
  },
  getBehaviorName: function(behaviorName) {
    return eventsFunctionContext._behaviorNamesMap[behaviorName] || behaviorName;
  },
  createObject: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    if (objectsList) {
      const object = parentEventsFunctionContext ?
        parentEventsFunctionContext.createObject(objectsList.firstKey()) :
        runtimeScene.createObject(objectsList.firstKey());
      if (object) {
        objectsList.get(objectsList.firstKey()).push(object);
        eventsFunctionContext._objectArraysMap[objectName].push(object);
      }
      return object;    }
    return null;
  },
  getInstancesCountOnScene: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    let count = 0;
    if (objectsList) {
      for(const objectName in objectsList.items)
        count += parentEventsFunctionContext ?
parentEventsFunctionContext.getInstancesCountOnScene(objectName) :
        runtimeScene.getInstancesCountOnScene(objectName);
    }
    return count;
  },
  getLayer: function(layerName) {
    return runtimeScene.getLayer(layerName);
  },
  getArgument: function(argName) {
    return "";
  },
  getOnceTriggers: function() { return that._onceTriggers; }
};

gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.SharedRandomOfSceneContext.GDObjectObjects1.length = 0;

gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.SharedRandomOfSceneContext.eventsList0(runtimeScene, eventsFunctionContext);

return Number(eventsFunctionContext.returnValue) || 0;
}

gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer.prototype.doStepPreEvents = function() {
  this._onceTriggers.startNewFrame();
};


gdjs.registerBehavior("OnlineMultiplayer::OnlinePlayer", gdjs.evtsExt__OnlineMultiplayer__OnlinePlayer.OnlinePlayer);
