gdjs.JoinCode = {};
gdjs.JoinCode.GDNewTextObjects1= [];
gdjs.JoinCode.GDNewTextObjects2= [];
gdjs.JoinCode.GDNewText2Objects1= [];
gdjs.JoinCode.GDNewText2Objects2= [];
gdjs.JoinCode.GDFloatingOutButtonDarkBlueObjects1= [];
gdjs.JoinCode.GDFloatingOutButtonDarkBlueObjects2= [];
gdjs.JoinCode.GDBlueButtonWithShadowObjects1= [];
gdjs.JoinCode.GDBlueButtonWithShadowObjects2= [];
gdjs.JoinCode.GDBlueButtonWithShadow2Objects1= [];
gdjs.JoinCode.GDBlueButtonWithShadow2Objects2= [];
gdjs.JoinCode.GDNewTextInputObjects1= [];
gdjs.JoinCode.GDNewTextInputObjects2= [];


gdjs.JoinCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("FloatingOutButtonDarkBlue"), gdjs.JoinCode.GDFloatingOutButtonDarkBlueObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.JoinCode.GDFloatingOutButtonDarkBlueObjects1.length;i<l;++i) {
    if ( gdjs.JoinCode.GDFloatingOutButtonDarkBlueObjects1[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.JoinCode.GDFloatingOutButtonDarkBlueObjects1[k] = gdjs.JoinCode.GDFloatingOutButtonDarkBlueObjects1[i];
        ++k;
    }
}
gdjs.JoinCode.GDFloatingOutButtonDarkBlueObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Multiplayer Lobby", false);
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.JoinCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.JoinCode.GDNewTextObjects1.length = 0;
gdjs.JoinCode.GDNewTextObjects2.length = 0;
gdjs.JoinCode.GDNewText2Objects1.length = 0;
gdjs.JoinCode.GDNewText2Objects2.length = 0;
gdjs.JoinCode.GDFloatingOutButtonDarkBlueObjects1.length = 0;
gdjs.JoinCode.GDFloatingOutButtonDarkBlueObjects2.length = 0;
gdjs.JoinCode.GDBlueButtonWithShadowObjects1.length = 0;
gdjs.JoinCode.GDBlueButtonWithShadowObjects2.length = 0;
gdjs.JoinCode.GDBlueButtonWithShadow2Objects1.length = 0;
gdjs.JoinCode.GDBlueButtonWithShadow2Objects2.length = 0;
gdjs.JoinCode.GDNewTextInputObjects1.length = 0;
gdjs.JoinCode.GDNewTextInputObjects2.length = 0;

gdjs.JoinCode.eventsList0(runtimeScene);

return;

}

gdjs['JoinCode'] = gdjs.JoinCode;
