gdjs.AboutCode = {};
gdjs.AboutCode.GDNewTextObjects1= [];
gdjs.AboutCode.GDNewTextObjects2= [];
gdjs.AboutCode.GDFloatingOutButtonDarkBlueObjects1= [];
gdjs.AboutCode.GDFloatingOutButtonDarkBlueObjects2= [];


gdjs.AboutCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("FloatingOutButtonDarkBlue"), gdjs.AboutCode.GDFloatingOutButtonDarkBlueObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.AboutCode.GDFloatingOutButtonDarkBlueObjects1.length;i<l;++i) {
    if ( gdjs.AboutCode.GDFloatingOutButtonDarkBlueObjects1[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.AboutCode.GDFloatingOutButtonDarkBlueObjects1[k] = gdjs.AboutCode.GDFloatingOutButtonDarkBlueObjects1[i];
        ++k;
    }
}
gdjs.AboutCode.GDFloatingOutButtonDarkBlueObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Menu", false);
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.AboutCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.AboutCode.GDNewTextObjects1.length = 0;
gdjs.AboutCode.GDNewTextObjects2.length = 0;
gdjs.AboutCode.GDFloatingOutButtonDarkBlueObjects1.length = 0;
gdjs.AboutCode.GDFloatingOutButtonDarkBlueObjects2.length = 0;

gdjs.AboutCode.eventsList0(runtimeScene);

return;

}

gdjs['AboutCode'] = gdjs.AboutCode;
