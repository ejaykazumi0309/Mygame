gdjs.POP_32UPCode = {};
gdjs.POP_32UPCode.GDGroundTileObjects1= [];
gdjs.POP_32UPCode.GDGroundTileObjects2= [];
gdjs.POP_32UPCode.GDFloatingOutButtonDarkBlueObjects1= [];
gdjs.POP_32UPCode.GDFloatingOutButtonDarkBlueObjects2= [];
gdjs.POP_32UPCode.GDFloatingOutButtonDarkBlue2Objects1= [];
gdjs.POP_32UPCode.GDFloatingOutButtonDarkBlue2Objects2= [];
gdjs.POP_32UPCode.GDMenuPopupBackgroundObjects1= [];
gdjs.POP_32UPCode.GDMenuPopupBackgroundObjects2= [];
gdjs.POP_32UPCode.GDRestartObjects1= [];
gdjs.POP_32UPCode.GDRestartObjects2= [];


gdjs.POP_32UPCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("FloatingOutButtonDarkBlue"), gdjs.POP_32UPCode.GDFloatingOutButtonDarkBlueObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.POP_32UPCode.GDFloatingOutButtonDarkBlueObjects1.length;i<l;++i) {
    if ( gdjs.POP_32UPCode.GDFloatingOutButtonDarkBlueObjects1[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.POP_32UPCode.GDFloatingOutButtonDarkBlueObjects1[k] = gdjs.POP_32UPCode.GDFloatingOutButtonDarkBlueObjects1[i];
        ++k;
    }
}
gdjs.POP_32UPCode.GDFloatingOutButtonDarkBlueObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.popScene(runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("FloatingOutButtonDarkBlue2"), gdjs.POP_32UPCode.GDFloatingOutButtonDarkBlue2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.POP_32UPCode.GDFloatingOutButtonDarkBlue2Objects1.length;i<l;++i) {
    if ( gdjs.POP_32UPCode.GDFloatingOutButtonDarkBlue2Objects1[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.POP_32UPCode.GDFloatingOutButtonDarkBlue2Objects1[k] = gdjs.POP_32UPCode.GDFloatingOutButtonDarkBlue2Objects1[i];
        ++k;
    }
}
gdjs.POP_32UPCode.GDFloatingOutButtonDarkBlue2Objects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Menu", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Restart"), gdjs.POP_32UPCode.GDRestartObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.POP_32UPCode.GDRestartObjects1.length;i<l;++i) {
    if ( gdjs.POP_32UPCode.GDRestartObjects1[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.POP_32UPCode.GDRestartObjects1[k] = gdjs.POP_32UPCode.GDRestartObjects1[i];
        ++k;
    }
}
gdjs.POP_32UPCode.GDRestartObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "StartMenu", false);
}}

}


};

gdjs.POP_32UPCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.POP_32UPCode.GDGroundTileObjects1.length = 0;
gdjs.POP_32UPCode.GDGroundTileObjects2.length = 0;
gdjs.POP_32UPCode.GDFloatingOutButtonDarkBlueObjects1.length = 0;
gdjs.POP_32UPCode.GDFloatingOutButtonDarkBlueObjects2.length = 0;
gdjs.POP_32UPCode.GDFloatingOutButtonDarkBlue2Objects1.length = 0;
gdjs.POP_32UPCode.GDFloatingOutButtonDarkBlue2Objects2.length = 0;
gdjs.POP_32UPCode.GDMenuPopupBackgroundObjects1.length = 0;
gdjs.POP_32UPCode.GDMenuPopupBackgroundObjects2.length = 0;
gdjs.POP_32UPCode.GDRestartObjects1.length = 0;
gdjs.POP_32UPCode.GDRestartObjects2.length = 0;

gdjs.POP_32UPCode.eventsList0(runtimeScene);

return;

}

gdjs['POP_32UPCode'] = gdjs.POP_32UPCode;
