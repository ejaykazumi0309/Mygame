gdjs.LeaderboardCode = {};
gdjs.LeaderboardCode.GDNewTextObjects1= [];
gdjs.LeaderboardCode.GDNewTextObjects2= [];
gdjs.LeaderboardCode.GDNewText2Objects1= [];
gdjs.LeaderboardCode.GDNewText2Objects2= [];
gdjs.LeaderboardCode.GDNewText22Objects1= [];
gdjs.LeaderboardCode.GDNewText22Objects2= [];
gdjs.LeaderboardCode.GDNewText222Objects1= [];
gdjs.LeaderboardCode.GDNewText222Objects2= [];
gdjs.LeaderboardCode.GDNewText2222Objects1= [];
gdjs.LeaderboardCode.GDNewText2222Objects2= [];
gdjs.LeaderboardCode.GDNewText22222Objects1= [];
gdjs.LeaderboardCode.GDNewText22222Objects2= [];
gdjs.LeaderboardCode.GDNewText222222Objects1= [];
gdjs.LeaderboardCode.GDNewText222222Objects2= [];
gdjs.LeaderboardCode.GDFloatingOutButtonDarkBlueObjects1= [];
gdjs.LeaderboardCode.GDFloatingOutButtonDarkBlueObjects2= [];


gdjs.LeaderboardCode.eventsList0 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.leaderboards.isLeaderboardViewLoaded());
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.popScene(runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("FloatingOutButtonDarkBlue"), gdjs.LeaderboardCode.GDFloatingOutButtonDarkBlueObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LeaderboardCode.GDFloatingOutButtonDarkBlueObjects1.length;i<l;++i) {
    if ( gdjs.LeaderboardCode.GDFloatingOutButtonDarkBlueObjects1[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.LeaderboardCode.GDFloatingOutButtonDarkBlueObjects1[k] = gdjs.LeaderboardCode.GDFloatingOutButtonDarkBlueObjects1[i];
        ++k;
    }
}
gdjs.LeaderboardCode.GDFloatingOutButtonDarkBlueObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Menu", false);
}}

}


};

gdjs.LeaderboardCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.LeaderboardCode.GDNewTextObjects1.length = 0;
gdjs.LeaderboardCode.GDNewTextObjects2.length = 0;
gdjs.LeaderboardCode.GDNewText2Objects1.length = 0;
gdjs.LeaderboardCode.GDNewText2Objects2.length = 0;
gdjs.LeaderboardCode.GDNewText22Objects1.length = 0;
gdjs.LeaderboardCode.GDNewText22Objects2.length = 0;
gdjs.LeaderboardCode.GDNewText222Objects1.length = 0;
gdjs.LeaderboardCode.GDNewText222Objects2.length = 0;
gdjs.LeaderboardCode.GDNewText2222Objects1.length = 0;
gdjs.LeaderboardCode.GDNewText2222Objects2.length = 0;
gdjs.LeaderboardCode.GDNewText22222Objects1.length = 0;
gdjs.LeaderboardCode.GDNewText22222Objects2.length = 0;
gdjs.LeaderboardCode.GDNewText222222Objects1.length = 0;
gdjs.LeaderboardCode.GDNewText222222Objects2.length = 0;
gdjs.LeaderboardCode.GDFloatingOutButtonDarkBlueObjects1.length = 0;
gdjs.LeaderboardCode.GDFloatingOutButtonDarkBlueObjects2.length = 0;

gdjs.LeaderboardCode.eventsList0(runtimeScene);

return;

}

gdjs['LeaderboardCode'] = gdjs.LeaderboardCode;
